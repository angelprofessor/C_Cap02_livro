/* CelsiusFah1.C */
/* Converte temperaturas de graus Celsius para Fahrenheit */
#include <stdio.h>
#include <stdlib.h>

int main()				
{
	float ctemp;
	printf("Digite temperatura em graus Celsius: ");
	scanf("%f",&ctemp);
	printf("\nTemperatura em graus Fahrenheit e' %.2f\n", ctemp * 9/5 + 32);

    	system("PAUSE");	
    	return 0;			
}
