/* Getche.C */
/* Mostra a fun��o getche() */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>	/* para getche() e getch() */

int main()				
{
	char ch;
	printf("\nPressione uma tecla ");
	ch = _getche();	/* aguarda uma tecla no teclado */
	printf("\nA tecla sucessora ASCII e %c.\n", ch+1);
   // system("PAUSE");	
    return 0;			
}




