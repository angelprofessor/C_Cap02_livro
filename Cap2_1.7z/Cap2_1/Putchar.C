/* Putchar.C */
/* Mostra a fun��o getchar() e putchar() */
#include <stdio.h>
#include <stdlib.h>

int main()				
{
	char ch;
	printf("\nPressione uma tecla ");
	ch = getchar();	/* aguarda uma tecla no teclado */
	printf("\nA tecla sucessora ASCII � ");
	putchar(ch+1);
	putchar('\n');
    	system("PAUSE");	
    	return 0;			
}





