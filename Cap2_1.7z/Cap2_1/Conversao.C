/* Conversao.C */
/* Convers�o de tipo autom�tica */
#include <stdio.h>
#include <stdlib.h>

int main()				
{
    int VarInt=2000000000;
    int Dez =10;
    VarInt = (VarInt * Dez) / Dez;     /* valor muito grande */
    printf("\nVarInt = %d\n", VarInt); /* resposta errada    */	
    system("PAUSE");	
    return 0;	
}


